const prices = {
    brick: {
        base: 2300,
        cm1: 0,
        cm2: 400,
        cm3: 500,
        cm4: 900,
        colorNone: 0,
        colorDark: 400,
        colorLight: 1000,
        dekarat: 300,
    },
    corona: {
        base: 1600,
        cm1: 0,
        cm2: 800,
        cm3: 1200,
        cm4: 1600,
        colorNone: 0,
        colorDark: 400,
        colorLight: 1000,
        dekarat: 300,
    },
    stone: {
        base: 2450,
        cm1: 0,
        cm2: 250,
        cm3: 750,
        cm4: 1150,
        colorNone: 0,
        colorDark: 400,
        colorLight: 1000,
        dekarat: 300,

    },
    castle: {
        base: 1500,
        cm1: 0,
        cm2: 900,
        cm3: 1300,
        cm4: 1700,
        colorNone: 0,
        colorDark: 400,
        colorLight: 1000,
        dekarat: 300,

    },
    wood: {
        base: 2300,
        cm1: 0,
        cm2: 100,
        cm3: 400,
        cm4: 700,
        colorNone: 0,
        colorDark: 400,
        colorLight: 1000,
        dekarat: 300,

    },
    classicStone: {
        base: 2450,
        cm1: 0,
        cm2: 350,
        cm3: 750,
        cm4: 1150,
        colorNone: 0,
        colorDark: 400,
        colorLight: 1000,
        dekarat: 300,
    }
};

let finalPrice = prices.base;
let thickness = null;
let colorless = null;
let dekarat = null;
let nThick = 0;
let nColor = 0;
let nDekarat = 0;

const thickRadio = document.querySelectorAll(".thick-box input");
const colorsRadio = document.querySelectorAll(".color-box input");
let dekaratChk = document.querySelectorAll(".options-box input");
let priceText = document.querySelectorAll(".price");
let cards = document.querySelectorAll(".card");
let price = {};

function changePrices(priceSet) {
    // let price = c.dataset.card;
    switch (priceSet) {
        case 'brick':
            price = prices.brick;
            console.log(price);
            break;
        case 'corona':
            price = prices.corona;
            console.log(price);
            break;
        default:
            break;
        case 'stone':
            price = prices.stone;
            console.log(price)
            break;
        case 'castle':
            price = prices.castle;
            console.log(price)
            break;
        case 'wood':
            price = prices.wood;
            console.log(price)
            break;
        case 'classicStone':
            price = prices.classicStone;
            console.log(price)
            break;
    }

}

for (const t of thickRadio) {
    t.addEventListener("click", function () {
        finalPrice = Number(
            this.parentNode.parentNode.children[6].children[0].textContent
        );
        let parentData = this.parentNode.dataset.thickPrice;
        let priceSet = this.parentNode.parentNode.dataset.card;
        changePrices(priceSet);

        if (this.checked) {
            if (this.value == "1cm") {
                finalPrice -= Number(parentData);
                finalPrice += price.cm1;
                this.parentNode.dataset.thickPrice = price.cm1;
            } else if (this.value == "2cm") {
                finalPrice -= Number(parentData);
                finalPrice += price.cm2;
                this.parentNode.dataset.thickPrice = price.cm2;
            } else if (this.value == "3cm") {
                finalPrice -= Number(parentData);
                finalPrice += price.cm3;
                this.parentNode.dataset.thickPrice = price.cm3;
            } else if (this.value == "4cm") {
                finalPrice -= Number(parentData);
                finalPrice += price.cm4;
                this.parentNode.dataset.thickPrice = price.cm4;
            }
        }
        this.parentNode.parentNode.children[6].children[0].textContent =
            finalPrice;
    });
}

for (const c of colorsRadio) {
    c.addEventListener("click", function () {
        finalPrice = Number(
            this.parentNode.parentNode.children[6].children[0].textContent
        );
        let parentData = Number(this.parentNode.dataset.colorPrice);
        let priceSet = this.parentNode.parentNode.dataset.card;
        changePrices(priceSet);

        if (this.checked) {
            if (this.value == "none") {
                finalPrice -= Number(parentData);
                finalPrice += price.colorNone;
                this.parentNode.dataset.colorPrice = price.colorNone;
            } else if (this.value == "dark") {
                finalPrice -= Number(parentData);
                finalPrice += price.colorDark;
                this.parentNode.dataset.colorPrice = price.colorDark;
            } else if (this.value == "light") {
                finalPrice -= Number(parentData);
                finalPrice += price.colorLight;
                this.parentNode.dataset.colorPrice = price.colorLight;
            }
        }
        this.parentNode.parentNode.children[6].children[0].textContent =
            finalPrice;
    });
}

for (const dekarat of dekaratChk) {
    dekarat.addEventListener("click", function () {

        let priceSet = this.parentNode.parentNode.dataset.card;
        changePrices(priceSet);

        finalPrice = Number(
            this.parentNode.parentNode.children[6].children[0].textContent
        );
        let parentData = Number(this.parentNode.dataset.dekaratPrice);

        if (this.checked) {
            finalPrice += price.dekarat;
            this.parentNode.dataset.dekaratPrice = price.dekarat;
        } else {
            finalPrice -= price.dekarat;
            this.parentNode.dataset.dekaratPrice = 0;
        }
        this.parentNode.parentNode.children[6].children[0].textContent =
            finalPrice;
    });
}
window.onload = function () {
    var cards = document.querySelectorAll('.card');
    var maxHeight = 0;

    cards.forEach(function (card) {
        var cardHeight = card.offsetHeight;
        maxHeight = Math.max(maxHeight, cardHeight);
    });

    cards.forEach(function (card) {
        card.style.height = maxHeight + 'px';
    });
};
